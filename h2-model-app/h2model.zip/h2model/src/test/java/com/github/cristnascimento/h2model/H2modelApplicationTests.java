package com.github.cristnascimento.h2model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2modelApplicationTests {

	@Test
	void contextLoads() {
	}

}
