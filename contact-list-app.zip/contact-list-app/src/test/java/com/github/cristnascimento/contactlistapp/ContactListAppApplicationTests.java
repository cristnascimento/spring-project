package com.github.cristnascimento.contactlistapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactListAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
