package com.github.cristnascimento.contactlistapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactListAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactListAppApplication.class, args);
	}

}
